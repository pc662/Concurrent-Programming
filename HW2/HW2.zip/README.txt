You can do 
"make all"
To compile and make all the images